<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>OR005 - category_item_selectValue</name>
   <tag></tag>
   <elementGuidId>23cbd572-e044-43af-8e7f-90e53b57af4d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>id.binar.fp.secondhand:id/tv_product_location</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//*[@resource-id = 'id.binar.fp.secondhand:id/tv_product_location']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>resource-id</name>
      <type>Main</type>
      <value>id.binar.fp.secondhand:id/tv_product_location</value>
      <webElementGuid>f4f4890a-1245-4f4f-8724-935540ef1f0a</webElementGuid>
   </webElementProperties>
</WebElementEntity>
